<?php 
session_start();
// $_SESSION['user']="Admin";
// echo session_id();
// echo $_SESSION['user'];
// $_SESSION['user']="user";
// echo $_SESSION['user'];
// //unset($_SESSION['user']);
// session_destroy();
// echo $_SESSION['user'];


if(isset($_SESSION['count']))
     $_SESSION['count']++;
else
     $_SESSION['count']=1;

     echo $_SESSION['count'];
?>