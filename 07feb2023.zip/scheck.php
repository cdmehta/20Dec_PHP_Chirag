<?php 
session_start();
if($_SESSION['uname']=="")
    header("location:login.php");
?>