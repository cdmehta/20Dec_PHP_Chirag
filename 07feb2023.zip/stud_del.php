<?php 
include("connect.php");
$d="select *  from stud_mst where stud_id=".$_GET['stud_id']; 
$res=mysqli_query($cn,$d);
$row=mysqli_fetch_object($res);
 $img="uploadedfiles/".$row->stud_img;
unlink($img);

$q="delete  from stud_mst where stud_id=".$_GET['stud_id'];
$res=mysqli_query($cn,$q);
header("location:stud_disp.php");
?>
