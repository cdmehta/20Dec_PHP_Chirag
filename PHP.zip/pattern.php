
<?php 
$n=10;/*
for($i=1;$i<=$n;$i++)
{
	for($j=1;$j<=$i;$j++)
	{
		echo "*";
	}
	echo "<br>";
}*/
for($i=1;$i<=$n;$i++)
{
	for($j=1;$j<=$n;$j++)
	{
		if($i==1 || $j==$n || $i==$n)
			echo "*";
	}
	echo "<br>";
}
/*$a='1';
$b=&$a;
$b="2$b";
echo $a."<br>";
echo $b."<br>";
*/
$arr=array("Even","Odd");
$num=15;
echo $arr[$num%2]."<br>";

$a='1';
$b=&$a;
$b="2$b";
echo $a."<br>";
echo $b."<br>";
?>