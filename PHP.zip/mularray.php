<?php 
/*$balance=array(
	array(1,2,3,4,5),
	array(1,2,3,4,5),
	array(1,2,3,4,5));
	//print_r($balance);
	for($i=0;$i<count($balance);$i++)
	{
	for($j=0;$j<count($balance[$i]);$j++)
		{
			echo $balance[$i][$j]."&nbsp;&nbsp;";
		}
		echo "<br>";
	}*/
	

$i=1;


if($i<=10)
{
	goto a;echo $i;
	$i++;
	
}
a:
echo "Test";	
	
?>
