<?php
class class1
{
	function __construct()
	{
		echo "Constructor...";
	}
	function myfun()
	{
		echo "Function calling";
	}
}
class class2 extends class1
{
	
}
$cls2=new class2();
$cls2->myfun();
 ?>