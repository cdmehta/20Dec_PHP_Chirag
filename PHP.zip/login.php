<?php 
session_start();

include ("connect.php");
$msg="";
if(isset($_REQUEST['btnsubmit']))
{
    $q="select * from login_mst where
    login_username = '".$_REQUEST['txtuname']."' and
    login_password = '".$_REQUEST['txtpass']."' 
    ";
    $res=mysqli_query($cn,$q);
    if(mysqli_num_rows($res)>0)
    {
        $_SESSION['uname']=$_REQUEST['txtuname'];
        header("location:home.php");
    }
    else
        $msg= "<div class='alert alert-danger' align='center'>Invalid username or Password</div>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
    <h1 align="Center">
        Admin Login
    </h1>
    <?php echo $msg; ?>
    <form method="post">
    <div class="form-group">
    <label for="Username">Username</label>
    <input type="text" class="form-control"  placeholder="Enter Username" name="txtuname" required>    
  </div>
  <div class="form-group">
    <label for="Password">Password</label>
    <input type="password" class="form-control"  placeholder="Enter Password" name="txtpass"required>    
  </div>
 
  
  <button type="submit" class="btn btn-primary"name="btnsubmit">Login</button>
    </form>
</body>
</html>