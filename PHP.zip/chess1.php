<table border="2"height=200 width=300>
<?php 
    for($i=1;$i<=8;$i++){
        $val=$i;
        echo "<tr>";
        for($j=1;$j<=8;$j++)
        {
            if($val%2==0)
            {
                echo "<td bgcolor='black'></td>";
                $val++;
            }
            else
            {
                echo "<td bgcolor='white'></td>";
                $val++;
            }
        }
        echo "</tr>";
        
    }
?>
</table>