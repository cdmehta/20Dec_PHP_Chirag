-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2023 at 08:58 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_php`
--
CREATE DATABASE IF NOT EXISTS `db_php` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `db_php`;

-- --------------------------------------------------------

--
-- Table structure for table `dept_mst`
--

CREATE TABLE `dept_mst` (
  `dept_id` int(3) NOT NULL,
  `dept_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dept_mst`
--

INSERT INTO `dept_mst` (`dept_id`, `dept_name`) VALUES
(1, 'BCA'),
(2, 'B.B.A.'),
(3, 'B.Com'),
(4, 'mba');

-- --------------------------------------------------------

--
-- Table structure for table `login_mst`
--

CREATE TABLE `login_mst` (
  `login_id` int(3) NOT NULL,
  `login_username` varchar(50) NOT NULL,
  `login_password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_mst`
--

INSERT INTO `login_mst` (`login_id`, `login_username`, `login_password`) VALUES
(1, 'admin', 'f1c1592588411002af340cbaedd6fc33'),
(2, 'superadmin', '0a113ef6b61820daa5611c870ed8d5ee'),
(3, 'abc', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `stud_mst`
--

CREATE TABLE `stud_mst` (
  `stud_id` int(3) NOT NULL,
  `stud_name` varchar(30) NOT NULL,
  `stud_email` varchar(50) NOT NULL,
  `stud_address` varchar(100) NOT NULL,
  `stud_img` varchar(100) NOT NULL,
  `stud_dept` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stud_mst`
--

INSERT INTO `stud_mst` (`stud_id`, `stud_name`, `stud_email`, `stud_address`, `stud_img`, `stud_dept`) VALUES
(29, '123', '123@gmail.com', 'Baroda', 'Screenshot (2).png', 2),
(30, 'rty', '123@gmail.com', 'Surat', 'Screenshot (1).png', 4),
(31, 'sd', 'laxman@gmail.com', 'sdf', 'Screenshot (2).png', 4),
(32, 'chirag', '123@gmail.com', 'wer', 'Screenshot (2).png', 3),
(33, 'Ram', 'ram@gmail.com', 'Ayodhya', 'car.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dept_mst`
--
ALTER TABLE `dept_mst`
  ADD PRIMARY KEY (`dept_id`);

--
-- Indexes for table `login_mst`
--
ALTER TABLE `login_mst`
  ADD PRIMARY KEY (`login_id`);

--
-- Indexes for table `stud_mst`
--
ALTER TABLE `stud_mst`
  ADD PRIMARY KEY (`stud_id`),
  ADD KEY `stud_dept` (`stud_dept`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dept_mst`
--
ALTER TABLE `dept_mst`
  MODIFY `dept_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login_mst`
--
ALTER TABLE `login_mst`
  MODIFY `login_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stud_mst`
--
ALTER TABLE `stud_mst`
  MODIFY `stud_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
