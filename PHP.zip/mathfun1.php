<?php 
// echo abs(-4);
// echo ceil(5.2)."<br>";
// echo floor(5.5)."<br>";
// echo round(5.29,1)."<br>";
// echo min(12,3,434,565,678,98,9,23,0);
// $a=array(12,34,22,11);
// echo max($a);
// echo pow(2,5);
// echo sqrt(49);
 echo rand(1,10);
?>