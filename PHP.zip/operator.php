<?php 
//Local Variable
/*add();
function add()
{
	$a=10;
	$b=20;
	$c=$a+$b;
	echo $c;
	echo $a;
}

//echo $a;*/
//Function PArameter
/*function add($a,$b)
{
	$c=$a+$b;
	echo $c;
	echo $a;
}
add(10,20);
echo $a;*/

//Global Variable
/*$a=10;
function add()
{
	//GLOBAL $a;
	$c=$a*$a;
	echo $c;
}
add();
*/

//Static Variable
/*
function callme()
{
	STATIC $a=0;
	$a+=10;
	echo $a."<br>"; //10 20 30
}
#callme();
callme();
callme();*/
?>

<!--Simple if-->
<?php 
/*
$a=85;
if($a>=36)
{
	if($a>=80)
		echo "Great";
	else
		echo "PASS";
}
else 
	echo "FAIL";*/
/*$per=65;
if($per>=70)
	ECHO "DIST";
ELSE IF($per>=60 && $per<=69)
	echo "First";
else if()
	
else 
	*/
/*$c=20;
switch($c)
{
	case 1:
		echo "January";
		break;
	case 2:
		echo "February";
		break;
	default:
		echo "IC";
}*/
/*
$i=1;
while($i<=50) //False
{
	if($i==50)
		print $i;
	else
		print $i.",";
	
	$i++;
}*/
/*
$i=1;
do{
	echo $i;
	$i++;
}while($i<=50);*/
/*for($i=1;$i>=50;$i++)
	echo $i;*/
/*$a=array(1,2,3,4,5);
foreach($a as $v)
{
	echo $v;
}*/

/*
for($i=1;$i<=50;$i++)
{
	if($i==5)
		continue;
	echo $i;
}*//*
function square($a)
{
	//echo $a*$a;
	return $a*$a;
	
}
strlen("TOPS");*/
/*for($i=1;$i>=50;$i++)
	echo $i;
echo sqrt(49)
echo square(5);
*//*
$n=5;
for($i=1;$i<=$n;$i++)
{
	for($j=1;$j<=$n;$j++)
		echo $j;
	echo "<br>";
}

*/
/*
$a=100;
$b=200;
$c=30;
$max= ($a>$b) ? (($a>$c) ? $a : $c):(($b>$c)?$b:$c); 
echo $max;*/

?>

<h1 align=center>Chess Board</h1>
<table border=2 height="80%" width="50%" align="center"> 
<?php 
$r=8;
$c=8;
$val=0;
for($i=1;$i<=$c;$i++)
{
	echo "<tr>";
	$val=$i;
		for($j=1;$j<=$r;$j++)
		{
			if($val%2==0)
			{
				echo "<td bgcolor=black>&nbsp;</td>";
				$val++;
			}
			else
			{
				echo "<td >&nbsp;</td>";
				$val++;
			}
		}
	echo "</tr>";
}
?>
</table> 
