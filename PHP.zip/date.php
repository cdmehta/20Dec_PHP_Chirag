<?php
date_default_timezone_set('Asia/Calcutta'); 
$d=getdate();
echo "<pre>";
print_r($d);
//  $d=new DateTime();
//  $d->setDate(2023,14,35);
//  echo $d->format('d-m-Y');

//  var_dump(checkdate(2,29,2022));


// date_default_timezone_set('Asia/Calcutta'); 

 echo "The time is " . date("h:i:s a");
?>