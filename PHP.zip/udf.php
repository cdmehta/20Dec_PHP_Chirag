<?php 
//Without argument without Return Value
// function add()
// {
//     $a=10;$b=20;
//     echo $a+$b;
// }
// add();

//With argument without Return Value
// function add($a,$b)
// {
//     echo $a+$b;
// }
// add(10,20);


//Without argument with Return Value
// function add()
// {
//     $a=10;
//     $b=20;
//     return $a+$b;
// }
//  $c=add();
//  echo $c;

//With argument with Return Value
// function add($a,$b)
// {
//     return $a+$b;
// }
//  $c=add(10,20);
//  echo $c;

//Defaule Argument
// function add($a=0,$b=0)
// {
//     return $a+$b;
// }
//  $c=add();
//  echo $c;


function sqr($i)
{
    return $i*$i;
}
echo sqr(4);
?>