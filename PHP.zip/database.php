<?php 
$cn=mysqli_connect("localhost","root","admin@123","db_php");
if(!$cn)
    exit("Problem in Connection");
//echo $q="insert into stud_mst values(NULL,'Ravan','ravan@gmail.com','Lanka')";
//mysqli_query($cn,$q);

//$q="delete from stud_mst where stud_name='Sitaram'";
//mysqli_query($cn,$q);

// $q="update stud_mst
// set stud_address='Sri Lanka'
// where stud_id=7
// ";
// mysqli_query($cn,$q);

$q="select * from stud_mst";
 $res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
echo "<pre>";
print_r($row);
?>
