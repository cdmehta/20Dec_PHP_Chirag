<?php
$s="Tops Technologies";
// echo chr(65);
// echo ord('A');
// echo strlen($s);
// echo strtolower($s);
// echo strtoupper($s);
//echo ltrim($s);
// var_dump(rtrim($s));
// echo ucfirst("tops");
//echo substr($s,2,2);
/*for($i=0;$i<strlen($s);$i++)
{
    // echo $s[$i]."<br>";
    echo substr($s,0,$i)."<br>";
}*/
$a="ABC";      //65 66 67
$b="ABc";      //65 66  68
//echo strcasecmp($a,$b);
/*if(strcasecmp($a,$b)==0)
    echo "Same";
else    
    echo "Different";*/
    //$s="TOPS Surat";
    //echo strpos($s,"S",4);
    //echo stristr($s,"s");
    $s="This"; //4-1 =3
   // echo str_replace("is","was",$s,$c);
    //echo $c;
    //echo strrev($s);
    for($i=strlen($s)-1;$i>=0;$i--)
        echo $s[$i];
?>
