<?php 
//exp1 ? exp2 : exp3

$a=10;$b=20;


echo --$a."<br>"; //post increment  11
echo ++$a."<br>";
echo $a++;
echo $a;
/*$a=100;
$b=100;
$c=200;
$d=200;
if($a!=$b xor $c<=$d)
	echo "Both are same";
else
	echo "Not same";
*/
?>
<?php
/*echo $a-$b."<br>";
echo $a*$b."<br>";
echo $a/$b."<br>";
echo $a%$b."<br>";
echo $b**2;*/
?>