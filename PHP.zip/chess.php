<h1> Chess Board</h1>
<table border=2 height="70%" width="50%">
	<?php 
	for($i=1;$i<=8;$i++)
	{
		$val=$i;
	?>
	<tr>
		<?php 
		for($j=1;$j<=8;$j++)
		{
			if($val%2==0)
			{
		?>
			<td bgcolor="black"></td>
			
		<?php $val++; } 
			else
			{
				?>
			<td ></td>
			<?php
		$val++;	}
		} ?>
	</tr>
	<?php } ?>
</table>
<?php 

?>