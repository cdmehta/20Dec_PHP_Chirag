<?php 
//12345678910
// 2 4 6 8 10
/*$n=10;
$s=$n;
for($i=1;$i<=$n;$i++)
{
	for($k=1;$k<=$s-$i;$k++)
		echo "&nbsp;";
	for($j=1;$j<=$i;$j++)
	{
		if($i==1 ||$j==1||$i==$n||$i==$j)
			echo "*";
		else
			echo "&nbsp;&nbsp;";
	}
	echo "<br>";
	//$s--;
}*/

$n=10;
$s=0;
for($i=$n;$i>=1;$i--)
{
	for($k=0;$k<=$s;$k++)
		echo "&nbsp;";
	for($j=1;$j<=$i;$j++)
	{
		if($i==1 ||$j==1||$i==$n||$i==$j)
			echo "*";
		else
			echo "&nbsp;&nbsp;";
	}
	echo "<br>";
	$s++;
}
?>