<?php
//$a=array("BCA","BBA","BCOM",12,14,556);
//$a=array("Name"=>"TOPS","address"=>"Surat","cell"=>9988);
$a=array(12,14,15,array("course"=>"bca","college"=>"Tops","add"=>array(12,12)));

print_r($a);
echo $a[3]["add"][0];
?>