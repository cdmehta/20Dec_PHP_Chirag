<?php
// echo chr(97);
// echo ord('ABC');
//$s="tops";
// echo strlen($s);
// echo strtolower($s);
// echo strtoupper($s);
// echo ucfirst($s);
// echo $s1="              ABC       ";
// echo ltrim($s1);
// var_dump($s1);
// $s2="Welcome to TOPS";
//echo substr($s2,3,4);
//  for($i=0;$i<strlen($s2);$i++)
// for($i=strlen($s2)-1;$i>=0;$i--)
// {
//     echo substr($s2,0,$i)."<br>";
// }

// $s="Tops";
// $s1="tops";
// if(strcasecmp($s,$s1)==0)
//     echo "Same";
// else   
//     echo "Different";


$s="Tops Technologies";
echo strpos($s,"T",2);


//require("mathfun1.php");
require_once("mathfun1.php");
echo "Fun";
?>