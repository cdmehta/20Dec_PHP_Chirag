<?php 
 $a=array("Surat","Baroda","Ahmedabad",12,4,55,6);
 $b=array("Vapi","Valsad","Anand");
// list($a1,$a2,$a3)=$a;
// echo $a1;
//echo count($a);
// if(in_array("Baroda",$a))
//     echo "Value found";
// else   
//     echo "Not found";
// echo next($a)."<br>"; //Baroda
// echo current($a)."<br>"; //Baroda
// echo prev($a)."<br>"; //Surat
// echo end($a)."<br>"; //Ahmeadabad
//print_r(each($a));
//print_r(array_merge($a,$b));
//print_r(array_reverse($a));

$c=array("Name"=>"Sitaram","City"=>"Surat","State"=>"Gujarat");
krsort($c);
print_r($c);
?>
