<?php 
include("connect.php");
$q="select * from dept_mst";
$res=mysqli_query($cn,$q);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <select>
        <option>Select Department</option>
        <?php 
        while($row=mysqli_fetch_object($res))
        {
            echo "<option>".$row->dept_name."</option>";
        }
        ?>
        
    </select>
</body>
</html>