<?php 
$n=10;
?>
<table border=2>
	<tr>
		<td>No.</td>
		<td>Sqare</td>
		<td>Cube</td>
	</tr>
	<?php 
	for($i=1;$i<=$n;$i++)
	{
		echo "<tr>";
			echo "<td>$i</td>";
			echo "<td>".($i*$i)."</td>";
			echo "<td>".($i*$i*$i)."</td>";
		echo "</tr>";
	}
	?>
</table>