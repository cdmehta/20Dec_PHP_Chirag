-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2023 at 11:11 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--
CREATE DATABASE IF NOT EXISTS `crud` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `crud`;

-- --------------------------------------------------------

--
-- Table structure for table `stud_mst`
--

CREATE TABLE `stud_mst` (
  `stud_id` int(3) NOT NULL,
  `stud_name` varchar(30) NOT NULL,
  `stud_email` varchar(50) NOT NULL,
  `stud_address` varchar(100) NOT NULL,
  `stud_city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stud_mst`
--

INSERT INTO `stud_mst` (`stud_id`, `stud_name`, `stud_email`, `stud_address`, `stud_city`) VALUES
(7, 'tops Technologies', 'tops123@gmail.com', 'Varachha', 'Surat'),
(13, '1', '2', '3', '4'),
(18, '9', '9', '9', '9'),
(19, 'wer', 'werwer', 'werwer', 'werwer'),
(20, 'erww1', 'erer1', 'ertertert', 'erer1'),
(21, 'erer', 'erere', 'rere', 'erer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stud_mst`
--
ALTER TABLE `stud_mst`
  ADD PRIMARY KEY (`stud_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stud_mst`
--
ALTER TABLE `stud_mst`
  MODIFY `stud_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
