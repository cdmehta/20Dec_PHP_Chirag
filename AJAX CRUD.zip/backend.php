<?php 
$con=mysqli_connect("localhost","root","admin@123","crud");

extract($_POST);
// $fname=$_POST['fname'];
// $email=$_POST['email'];
// $address=$_POST['address'];
// $city=$_POST['city'];
if( isset($_POST['fname'])&& isset($_POST['email'])&& isset($_POST['address'])&& isset($_POST['city']))
{
echo $q="insert into stud_mst values(
    NULL,'$fname','$email','$address','$city'
)";
mysqli_query($con,$q);

}

if(isset($_POST['readrecords'])){
    $dq="select * from stud_mst";
    $res=mysqli_query($con,$dq);
    $data='<table class="table table-stripped">
        <tr>
            <th>Student Id</th>
            <th>Student Name</th>
            <th>Student Email</th>
            <th>Student Address</th>
            <th>Student City</th>
            <th>EDIT</th>
            <th>DELETE</th>
        </tr>';
        while($row=mysqli_fetch_object($res)){
            $data.='<tr>
            <td>'.$row->stud_id.'</td>
            <td>'.$row->stud_name.'</td>
            <td>'.$row->stud_email.'</td>
            <td>'.$row->stud_address.'</td>
            <td>'.$row->stud_city.'</td>
            <td><button class="btn btn-primary" onclick="getstuddata('.$row->stud_id.')">EDIT</button></td>
            <td><button class="btn btn-danger" onclick="getsid('.$row->stud_id.')">DELETE</button></td>
            </tr>';
        
        }


    $data.='</table>';

    echo $data;
}
if(isset($_POST['sid'])){
    $sid=$_POST['sid'];
    $delq="delete from stud_mst where stud_id=$sid";
    mysqli_query($con,$delq);
}

if(isset($_POST['editid'])){
    $editid=$_POST['editid'];
    $selq="select * from stud_mst where stud_id=$editid";
    $res=mysqli_query($con,$selq);
    $row=mysqli_fetch_object($res);
    echo json_encode($row);
}

if(isset($_POST['hidden_id'])){
    $hidden_id=$_POST['hidden_id'];
    $name=$_POST['name'];
    $email=$_POST['email'];
    $address=$_POST['address'];
    $city=$_POST['city'];

    $u="update stud_mst set 
    stud_name='$name',
    stud_email='$email',
    stud_address='$address',
    stud_city='$city' where 
    stud_id=$hidden_id";
    mysqli_query($con,$u);
    
}
?>