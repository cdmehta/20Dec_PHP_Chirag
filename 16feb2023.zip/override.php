<?php 
class A
{
    function override()
    {
        echo "Override called";
    }
}
class B extends A
{
    function override()
    {
        echo "Override called";
    }
}
$a=new A();
$a->override();
$b=new B();
$b->override();
?>