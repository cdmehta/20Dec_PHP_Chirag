<?php 
$n=4;
$k=1;
$c=1;
echo "<table border=2>";
for($i=1;$i<=$n;$i++)
{
    echo "<tr>";
    for($j=1;$j<=$n;$j++)
    {
        echo "<td>".$k."</td>";
        // if($k%4==0)
        //     echo $k."<br>";
        // else
        //     echo $k."&nbsp;";
        $k+=4;
        // $c++;
    }
    echo "<tr>";

}
echo "</table>";
?>