<?php
class A    //Class declaration
{
   protected function add()
   {
        echo "Method Called";
   }
}
class B extends A
{
    function __construct()
    {
        echo "Child Class Constructor";
         A::add();
    }
}
$b=new B(); //Object declaration

?>