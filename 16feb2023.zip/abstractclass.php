<?php 
abstract class Myclass
{
    abstract function cal($a);
}
class square extends Myclass
{
    function cal($a)
    {
        return $a*$a;
    }
}
class cube extends Myclass
{
    function cal($a)
    {
        return $a*$a*$a;
    }
}
$s=new square();
echo $s->cal(3)."<br>";
$c=new cube();
echo $c->cal(3);

?>