
<?php 
//1 without argu without return
// function add()
// {
//     $a=10;
//     $b=20;
//     echo $a+$b;
// }
// add();
//2 with argu without return
// function add($a,$b)
// {
//     echo $a+$b;
// }
// add(40,50);
//3 without argu with return
// function add()
// {
//     $a=10;
//     $b=50;
//     return $a+$b;
// }
// echo add();
//4 with argu with return
// function add($a,$b)
// {
//     return $a+$b;
// }
//echo add(10,80);
//5 Optional paramaters 
// function add($a=0,$b=0)
// {
//     return $a+$b;
// }
// echo add(10);


function sqr($n)
{
    return $n*$n;
}
echo sqr(5);
?>