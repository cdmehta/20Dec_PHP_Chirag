<?php 
setcookie("uname","TOPS",time()-60*60*24*30*12);

echo $_COOKIE["uname"];
?>