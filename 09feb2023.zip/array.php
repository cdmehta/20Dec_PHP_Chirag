<?php
// $a[0]=10;
// $a[1]=20;
// $a[2]=30;
// //echo $a[2];
// print_r($a);
// $a=array("C"=>10,"SQL"=>20,"C++"=>30);
// $a=array("Name"=>"Sitaram","Add"=>"Surat","per"=>88.55);
// //print_r($a);
// echo $a["per"];

$a=array(array(1,2,3),"PHP"=>array("loop","condition",array(8,9,0)),"C++");
print_r($a);
echo $a[0][1];
echo $a["PHP"][2][1];
?>