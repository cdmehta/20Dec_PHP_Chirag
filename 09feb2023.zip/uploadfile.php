<?php
if(isset($_REQUEST['btnsubmit']))
{
    echo $_FILES['myfile']['name']."<br>";
    echo $_FILES['myfile']['type']."<br>";
    echo $_FILES['myfile']['size']."<br>";
    echo $_FILES['myfile']['error']."<br>";
    echo $_FILES['myfile']['tmp_name']."<br>";
    move_uploaded_file($_FILES['myfile']['tmp_name'],"uploadedfiles/".$_FILES['myfile']['name']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="post" enctype="multipart/form-data">
        Upload file : <input type="file" accept="image/*" name="myfile">
        <input type="submit" name="btnsubmit">
    </form>
</body>
</html>