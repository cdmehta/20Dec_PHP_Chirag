<?PHP 
echo abs(-3)."<br>";
echo ceil(3.3)."<br>";
echo floor(3.3)."<br>";
echo round(3.688,2)."<br>";
echo max(1,2,3,0,-8)."<br>";
$a=array(12,3,4,5,6,7,54,44,2,21,1,88);
echo min($a)."<br>";
echo pow(2,5)."<br>";
$b=20;
var_dump($b);
echo rand();
?>