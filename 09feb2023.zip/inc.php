<?php 
//require("udf.php");
//echo "Test";
header("location:arrayfun.php");
?>