<?php
$to="chi.mscit@gmail.com" ;
$subject="Mail from XAMPP";
$message="this is my actual message";
$header="This is just a header";
mail($to,$subject,$message,$header);
?>