<?php 
class main
{
    function __call($name, $arguments) //function name, array
    {
        if($name=='sum')
        {
        switch(count($arguments))
        {            
            case 2:
                return $arguments[0]+$arguments[1];
            case 3:
                return $arguments[0]+$arguments[1]+$arguments[2];
            
        }
    }
    }
}
$add2=new main();
echo $add2->sum(2,3)."<br>";
echo $add2->sum(2,3,4)."<br>";
 echo min(12,2,1,45,56,-8);
?>