<?php 
$xml="<data>demo</data>";
echo $xml;
?>