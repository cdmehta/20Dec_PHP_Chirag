<!--
Create a class with the name mathOP
which contain 
add()
sub()
mul()
div() -->
<?php 
class mathOP
{
    public $a;
    public $b;
    function __construct($a,$b)
    {
        $this->a=$a;
        $this->b=$b;
    }
    function add()
    {
        return $this->a+$this->b;
    }
    function sub()
    {
        return $this->a-$this->b;
    }
    function mul()
    {
        return $this->a*$this->b;
    }
}
$mo=new mathOP(40,20);
echo $mo->add()."<br>";
echo $mo->sub()."<br>";
echo $mo->mul()."<br>";

?>