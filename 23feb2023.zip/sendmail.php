<?php 
$to="chi.mscit@gmail.com";
$sub="Demo mail";
$msg="This is my MSG";
$m=mail($to,$sub,$msg);
if($m)
    echo "Mail Sent";
else
    echo "Problem in mail...";
?>