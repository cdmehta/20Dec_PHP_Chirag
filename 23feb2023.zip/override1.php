<?php
class A
{
    function test()
    {
        echo "Base Class";
    }
}
class B extends A
{
    function test()
    {
        echo "Child Class";
    }
}
$b=new B();
$b->test();
?>
<!-- 
    class abc
    {
        function add($a,$b)
        {
                $a+$b;
        }
        function add($a,$b,$c)
        {
            $a+$b+$c;
        }
    }
 -->