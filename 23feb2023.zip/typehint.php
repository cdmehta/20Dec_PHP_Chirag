<?php 
function add(int $a,int $b)
{ //mixed 
    return $a+$b;
}
echo add(4,4);
?>