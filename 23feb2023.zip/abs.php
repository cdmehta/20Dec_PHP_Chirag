<?php 
abstract class cal{
    abstract function result($n);
}
class square extends cal{
    function result($n){
        return $n*$n;
    }
}
class cube extends cal{
    function result($n){
        return$n*$n*$n;
    }
}
$s=new square();
echo $s->result(5)."<br>";

$c=new cube();
echo $c->result(5);
?>