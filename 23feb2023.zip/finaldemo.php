<?php 
final class a
{
    function __construct()
    {
        echo "Parent Constructor called...";
    }
}
class b extends a
{
    function __construct()
    {
        echo "child class constructor...";
    }

}

?>