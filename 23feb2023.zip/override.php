<?php 
class A
{
    function abc()
    {
        echo "Override called";
    }
}
class B extends A
{
    function abc()
    {
        echo "Override called";
    }
}
$a=new A();
$a->abc();
$b=new B();
$b->abc();
?>