<?php
 //$fs=fopen("test.txt","a");
//  echo fread($fs,5);
// echo fread($fs,filesize("test.txt"));
// echo filesize("test.txt")
// fwrite($fs,"Ring Road, Surat");

// $file="Audit Trial.pdf";
// if(is_readable($file))
//     echo "Readable";
// else
//     echo "Not Readable";
// if(is_writable($file))
//     echo "Writable";
// else
//     echo "Not Writable";

// $fs=fopen("test.txt","r");
// echo fgets($fs,10);
// print_r(file("test.txt"));
// echo file_get_contents("test.txt");
// file_put_contents("test1.txt","This will overwrite the file");

mail("sitaram@gmail.com","Exam Report","A1 in BCA Exam");



?>