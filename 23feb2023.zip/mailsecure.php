<?php 
$a='<b>This is test</b>';
echo strip_tags($a);
filter_var($a,)
?>