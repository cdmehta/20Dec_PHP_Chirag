<?php 
class staff
{
     public $name;
     public $pass="123";
    // const PI=3.14;
    // function __construct($name,$pass)
    // {
    //      $this->name=$name;
    //       $this->pass=$pass;
    // }
}

 class student extends staff
 {
     function __construct($name)
     {
        echo $this->name=$name;
     }
 }
$s=new student("chirag");
// $st=new student();
?>