<?php 
trait demo{
  public function test(){
    echo "this will be in all";
  }
}
class calltrait{
  use demo;
}
$ct=new calltrait();
$ct->test();
?>