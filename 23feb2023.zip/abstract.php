<?php 
 abstract class cal
{
   abstract function result($a);
}
class square extends cal
{
    function result($a)
    {
        return $a*$a;
    }
}
class cube extends cal
{
    function result($a)
    {
        return $a*$a*$a;
    }
}
$s=new square();
echo $s->result(5);
$c=new cube();
echo $c->result(5);
?> 