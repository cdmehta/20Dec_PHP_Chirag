<?php 
trait demo{
    public function kuchhbhi()
    {
        echo "Function from Trait";
    }
}

class demo1{
    use demo;
    
}
class demo2{
    use demo;
}
$d=new demo1();
$d->kuchhbhi();

$d1=new demo2();
$d1->kuchhbhi();
?>