<?php 
class Demo
{
    function __construct($n) 
    {
        echo "Constructor $n<br>";
    }
    function __destruct() 
    {
        echo "Destructor Called<br>";
    }
    function add($a,$b)
    {
        echo $a+$b."<br>";
    }
    
}
$d=new Demo(10);
$d->add(4,5); //d.add();
?>