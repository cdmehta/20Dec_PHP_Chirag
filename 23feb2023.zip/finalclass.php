<?php 
 class userdata{
    final function test(){
        echo "test";
    }
}
class loandata extends userdata{
    function test(){
        echo "test";
    }

}
 
?>