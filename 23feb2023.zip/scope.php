<?php
class Scop
{
    const PI=3.14;
    static $x=20;
}
echo Scop::PI;
?>