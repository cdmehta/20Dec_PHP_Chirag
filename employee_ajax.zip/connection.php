<?php
$server_name= "localhost";
$user_name= "root";
$password= "admin@123";
$database_name= "php_ajax";
$conn= mysqli_connect($server_name , $user_name , $password , $database_name); 
if ($conn) {  
// echo "connected" ; 
}
?> 